# CAP3104-Website
Finance Website


<!>PROPOSED FEATURES<!>

Calculators (6)
Main Menu bar (1)
Homepage(1)
Contact form(1)
Team Bio Buttons (5)

14 Total so far

*** Calculator ideas ***

Credit card interest paid calculator
Savings growth calculator
Auto loan calculator
Daily spending limit calculator
Exchange rate calculator
Monthly budget visualizer calculator


<!>TODOS<!>

* We need better icons for the calculators
* We need someone to make the storyboard for our next assignment (Hunter?)
* We need to make everything else go
